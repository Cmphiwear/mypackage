#mypackage
This library is created of how to use my package

##building this package locally
python setup.py sdist
